敌情预测 v3.16 简体中文（非官方汉化）
======================================

把 Vanilla Plus Megapack 的敌情预测面板汉化为简体中文，滚动方式与英文原版一致。
本包是**独立汉化包**；如果您使用整合包 v33，也可以直接用整合包内的汉化版，二者只需选一个。

对应版本
--------
整合包 v33 / 游戏 Steam build 25480438 / 1.8.46015.0 / 加载器 Bingus Shared Loader v18 或更新

安装
----
1. 关闭游戏，用 HD2Arsenal 或 HD2MM 导入本包（本包不含加载器）。
2. 与整合包同时使用时二选一：
   · 把本包优先级设为高于整合包；或
   · 在整合包选项里取消勾选 Know Your Constellation。
   同一时间只启用一种敌情预测，避免两个模块互相覆盖。
3. Purge / Deploy，正常启动游戏。

验证
----
%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EnemyIntelligence.log
首行应显示 v3.16-zh-CN。

卸载
----
停用本包 → Purge / Deploy，即可回到整合包自带的面板（或英文原版）。

说明
----
· 术语对齐游戏官方简体中文资源，非社区昵称。
· 汉化实现：放宽面板的 ASCII 文本限制（改为只禁控制字符与分号），并把跑马灯由
  「按字节切分」改为「按 UTF-8 字符边界切分」，随后重新编译打包。
· 仅本机可见，不改变游戏数值、难度与联机行为。
· 非官方汉化，与上游作者 CowboyBingus 无隶属关系；请支持原作者。
  https://github.com/CowboyBingus/VanillaPlusMegapack
