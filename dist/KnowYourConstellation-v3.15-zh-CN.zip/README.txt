敌情预测 · Know Your Constellation v3.15 —— 简体中文（非官方汉化）
================================================================

这是什么
--------
把 Vanilla Plus Megapack 里的敌情预测面板（mods/cowboybingus/enemy_intelligence，
上游版本 v3.15）的显示文本汉化为简体中文：编组标题/说明、面板标题、走马灯提示、
重型敌人名称。滚动方式与英文原版一致。

术语来源：游戏官方简体中文字符串资源（Steam build 25327279），非社区昵称。

安装
----
1. 关闭游戏。用 HD2Arsenal 或 HD2MM 导入本包。
2. 确保已安装 Bingus Shared Loader v16 或更新版本（本包不含加载器）。
3. 与 Vanilla Plus Megapack 同时使用时：
   * 把本包优先级设为高于整合包（默认优先级模式下放在整合包之后）；或
   * 在整合包的选项里取消勾选 "Know Your Constellation"。
   同一时间只启用一种敌情预测，避免两个模块互相覆盖。
4. Purge / Deploy，然后正常启动游戏。

验证是否生效
------------
日志 %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EnemyIntelligence.log
首行应显示 v3.15-zh-CN（本汉化版）。进入任务简报界面应看到中文滚动预报。

卸载
----
停用本包 → Purge / Deploy。若要恢复英文面板，启用整合包自带的敌情预测选项即可。

兼容性
------
* 仅适用于 Vanilla Plus Megapack v26 所支持的游戏版本：Steam build 25327279 /
  游戏程序 1.8.45850.0。模块内置游戏指纹校验，游戏更新后需要重新构建。
* 与英文原版使用相同的字体/材质资源，不改动其他任何 mod 资源。

制作说明与致谢
--------------
* 上游 mod 与整合包作者：CowboyBingus（https://github.com/CowboyBingus/VanillaPlusMegapack）。
* 本包为非官方汉化：把面板的 ASCII 文本校验放宽为“禁止控制字符与分号”，并把跑马灯
  由“按字节切分”改为“按 UTF-8 字符边界切分”（原逻辑会把汉字切成半截并触发
  Invalid caret advance），再替换文案后重新编译打包。
* 上游仓库当前未声明开源许可证（"No repository-wide license has been selected"）。
  公开发布前建议先向上游作者询问授权或确认其态度；至少在描述里注明这是非官方修改版，
  并保留上游链接与署名。请勿再分发整合包自带的缩略图等美术资源。
