Vanilla Plus Megapack - v33

Supports Steam build 25480438 / EXE 1.8.46015.0.
Requires the separate Bingus Shared Loader v18 / API 1.

1. Close Helldivers 2 and use either Arsenal or HD2MM.
2. Disable previous megapacks and standalone copies of features you want off.
   Enable only one Megapack variant (standard or Rows).
3. Import Vanilla-Plus-Megapack-v33.zip and Bingus Shared Loader v18.
4. With Arsenal's default priority, place the loader LAST. If first-mod
   priority is enabled, place the loader FIRST instead.
5. Open the pack's Options and select any of the sixteen independent mods.
   Review these choices after updates; defaults depend on your manager.
6. Purge / Deploy, then start the game. Close the game before changing options.

Enable the Mod Bindings Menu option to rebind Ship Station Hotkeys on the MODS
tab of Mouse & Keyboard or Controller. Without it, the shortcuts use Tab, F1
and F5-F8 aboard the ship while no menu is open. The option was named Galactic
Menu Hotkey before v29; confirm it is still checked after updating. Mod
Bindings Menu ships its own content/input.config override; another mod that
replaces that resource must be merged with it.

Enable the Mod Options Menu option to set Shallow Water Diving's maximum dive
depth on the MODS tab of the escape menu.

Mod Bindings Menu, Mod Options Menu and Flame Damage Fixed are also released
on their own. Use one copy of each: disable the standalone package or the
pack option.

https://github.com/CowboyBingus/BingusSharedLoader/releases/latest

Included revisions:
- Better Stratagem Bounce v15.3
- Hellpod Steering Unlocked v7.4
- Reinforcement Beacons Fixed v4.5
- Consistent Vaulting v8.8
- Shallow Water Diving v3.8
- Sentry Aim Retention v1.0.13
- Enemy Collision Synchronized v2.11.0
- Controllable Hover Pack v1.7
- Know Your Constellation v3.16
- Armory Preview Cache v22
- Clickable Scrollbars v2.14
- Arc Thrower Revamped v1.6
- Ship Station Hotkeys v1.7
- Flame Damage Fixed v1.0
- Mod Options Menu v1.0.1
- Mod Bindings Menu v2.0

Rows uses the static constellation forecast layout. All other resources match
the standard package. An unchecked option cannot disable a separately enabled
standalone copy. Remove older startup-replacing packages when migrating.

Offline regression, package and option-selection checks passed. Current-build
multiplayer behavior still needs in-game confirmation.
Logs: %LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs
