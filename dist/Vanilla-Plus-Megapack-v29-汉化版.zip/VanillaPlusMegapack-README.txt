Vanilla Plus Megapack - v29

Supports Steam build 25480438 / EXE 1.8.46015.0.
Requires the separate Bingus Shared Loader v17 or newer / API 1.

1. Close Helldivers 2 and use either Arsenal or HD2MM.
2. Disable previous megapacks and standalone copies of features you want off.
   Enable only one Megapack variant (standard or Rows).
3. Import Vanilla-Plus-Megapack-v29.zip and Bingus Shared Loader v17 or newer.
4. With Arsenal's default priority, place the loader LAST. If first-mod
   priority is enabled, place the loader FIRST instead.
5. Open the pack's Options and select any of the thirteen independent mods.
   Review these choices after updates; defaults depend on your manager.
6. Purge / Deploy, then start the game. Close the game before changing options.

Install Mod Bindings Menu v2.0 separately to rebind Ship Station Hotkeys on
the MODS tab of Mouse & Keyboard or Controller. Without it, the shortcuts use
Tab, F1 and F5-F8 aboard the ship while no menu is open. The option was named
Galactic Menu Hotkey before v29; confirm it is still checked after updating.
Mod Bindings Menu is not bundled in either Megapack variant.

https://github.com/CowboyBingus/BingusSharedLoader/releases/latest
https://github.com/CowboyBingus/ModBindingsMenu/releases/latest

Included revisions:
- Better Stratagem Bounce v15.3
- Hellpod Steering Unlocked v7.3
- Reinforcement Beacons Fixed v4.4
- Consistent Vaulting v8.7
- Shallow Water Diving v3.6
- Sentry Aim Retention v1.0.12
- Enemy Collision Synchronized v2.10.2
- Controllable Hover Pack v1.6
- Know Your Constellation v3.16
- Armory Preview Cache v22
- Clickable Scrollbars v2.14
- Arc Thrower Revamped v1.6
- Ship Station Hotkeys v1.7

Rows uses the static constellation forecast layout. All other resources match
the standard package. An unchecked option cannot disable a separately enabled
standalone copy. Remove older startup-replacing packages when migrating.

Offline regression, package and option-selection checks passed. New gameplay
fixes and current-build multiplayer behavior still need in-game confirmation.
Logs: %LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs
